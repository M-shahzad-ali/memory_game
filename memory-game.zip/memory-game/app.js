var  image_box = document.querySelector(".image-boxes");
var parentScore =document.querySelector(".parent-score");
var score = document.querySelector(".score")
let allid =[];
let allname= []
let cardwon = []

var imageArray=[
    {
        name:"cheeseburger",
        src:"images/cheeseburger.png",
    },
    {
        name:"fries",
        src:"images/fries.png",

    },
    {
        name:"hotdog",
        src:"images/hotdog.png",

    },
    {
        name:"ice-cream",
        src:"images/ice-cream.png",

    },
    {
        name:"milkshake",
        src:"images/milkshake.png",

    },
    {
        name:"pizza ",
        src:"images/pizza.png",

    },
    {
        name:"cheeseburger",
        src:"images/cheeseburger.png",
    },
    {
        name:"fries",
        src:"images/fries.png",

    },
    {
        name:"hotdog",
        src:"images/hotdog.png",

    },
    {
        name:"ice-cream",
        src:"images/ice-cream.png",

    },
    {
        name:"milkshake",
        src:"images/milkshake.png",

    },
    {
        name:"pizza ",
        src:"images/pizza.png",

    }
]
imageArray.sort(()=>0.5-Math.random())
// console.log(imageArray)

function imageset(){
    for(var i=0;i<imageArray.length;i++){
        var imageElement= document.createElement("img");
        imageElement.setAttribute("id",i)
        imageElement.setAttribute("class","front-images")
        imageElement.src = "images/blank.png";
        // console.log(imageElement.id)
        image_box.appendChild(imageElement)
    }
}
imageset();
var frontImages = document.querySelectorAll(".front-images");
// console.log(frontImages)




// console.log(frontImages)
frontImages.forEach(e=>{
    e.addEventListener("click",f=()=>{
        let getimageid = e.getAttribute("id")
        allid.push(getimageid)
        let getimagename = imageArray[getimageid].name;
        allname.push(getimagename)
        // console.log(allname)
        // console.log(allid)
        e.src = imageArray[getimageid].src
        console.log("ye hai"+allid[0])
      if(allid.length==2){
        setTimeout(checkimages,500)
      }
    })
})



function checkimages(){
  if(allid[0]==allid[1]){
    alert("you are clever but we extra ordinary");
    location.reload(); 
    
  }

    if( allname[0]== allname[1]){
     frontImages[allid[0]].src ="images/white.png";
     frontImages[allid[1]].src ="images/white.png";
     frontImages[allid[0]].style.pointerEvents = "none";
     frontImages[allid[1]].style.pointerEvents = "none";
     cardwon.push(allname)
    //  console.log(cardwon)
     score.innerHTML=cardwon.length;
    }
    else{
        frontImages[allid[0]].src ="images/blank.png"
        frontImages[allid[1]].src ="images/blank.png"
        // imageArray.sort(()=>0.5-Math.random());
        console.log(imageArray)
        
      
    }
 if(cardwon.length==(imageArray.length/2)){
    parentScore.innerHTML=`congratulation you win width score${cardwon.length}`

 }
     allid =[];
     allname= []

 }